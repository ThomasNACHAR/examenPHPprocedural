<?php
$dsn = 'mysql:dbname=exercice;host=localhost';
$user = 'root'

$dbh = new PDO($dsn, $user);
?>