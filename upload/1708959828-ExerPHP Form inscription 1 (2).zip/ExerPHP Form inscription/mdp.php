<?php
// Pour enregistrer le mot de passe dans la base de donnée
require_once('db.php');
// On vérifie si le formulaire a été envoyé
if(isset($_POST['submit']))
{
    // Je vais vérifier si j'ai bien les mots de passes et la clé
    if(!empty($_POST['password']) && !empty($_POST['password2']) && !empty($_POST['cle']))
    {
        // Je vérifie si la clé est dans la table
        $verif = $dbh->query('SELECT * FROM users WHERE cle = "'.$_POST['cle'].'"');
        if($verif->rowCount() > 0)
        {
            // Je vérifie si les MDP sont ok
            if($_POST['password'] == $_POST['password2'])
            {
                // Je hashe le mot de passe
                $password = password_hash($_POST['password'],PASSWORD_DEFAULT);
                // Je vais préparer ma requête pour l'enregistrement du MDP
                $req = $dbh->prepare('UPDATE users SET password = :password WHERE cle = :cle');
                $req->bindParam(':password',$password);
                $req->bindParam(':cle',$_POST['cle']);
                if($req->execute())
                {
                    // Je redirige vers login.php
                    header('location:login.php');
                    exit;
                }
                else
                {
                    // Si erreur SQL
                    echo "Impossible d'enregistrer le mot de passe";
                }
            }
            else
            {
                // Si les 2 mots de passes ne sont pas identiques
                echo "Mot de passe non identique";
            }
        }
        else
        {
            // Si il manque un mot de passe ou la clé
            echo "Information manquante";
        }
    }
    
}
?>
