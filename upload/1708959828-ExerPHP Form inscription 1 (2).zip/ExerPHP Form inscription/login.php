<?php
require_once('db.php');
// Je vérifie si le formulaire a été envoyé
if(isset($_POST['submit']))
{
    // Je vérifie si mes champs ont une valeur
    if(!empty($_POST['email']) && !empty($_POST['password']))
    {
        // Je fais ma requête pour vérifier si j'ai un user
        $req = $dbh->query('SELECT * FROM users WHERE email = "'.$_POST['email'].'" LIMIT 1');
        if($req->rowCount() == 1)
        {
            // Je range les infos du user dans un tableau associatif
            $user = $req->fetch(PDO::FETCH_ASSOC);
            // Je vérifie si le mot de passe est bon
            if(password_verify($_POST['password'],$user['password'])){
                // On va lui envoyer un mail
                use PHPMailer\PHPMailer\PHPMailer;
                use PHPMailer\PHPMailer\SMTP;
                use PHPMailer\PHPMailer\Exception;

                //Load Composer's autoloader
                require 'vendor/autoload.php';

                //Create an instance; passing `true` enables exceptions
                $mail = new PHPMailer(true);

                try {
                    //Server settings
                    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
                    $mail->isSMTP();                                            //Send using SMTP
                    $mail->Host       = 'dwwm2324.fr';                     //Set the SMTP server to send through
                    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                    $mail->Username   = 'contact@dwwm2324.fr';                     //SMTP username
                    $mail->Password   = 'm%]E5p2%o]yc';                               //SMTP password
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
                    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

                    //Recipients
                    $mail->setFrom('contact@dwwm2324.fr', 'PHP life');
                    $mail->addAddress($user['email'],$user['nom']);     //Add a recipient
                   //Content
                    $mail->isHTML(true);                                  //Set email format to HTML
                    $mail->Subject = 'Connexion à votre compte';
                    $mail->Body    = 'Un utilisateur vient de se connecter (ip ='.$_SERVER['REMOTE_ADDR'].')';
                    $mail->AltBody = 'Un utilisateur vient de se connecter (ip ='.$_SERVER['REMOTE_ADDR'].')';

                    $mail->send();
                    echo 'Vous êtes connecté';
                } catch (Exception $e) {
                    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Se connecter</title>
</head>
<body>
    <h1>Se connecter</h1>
    <form name="login" method="POST" action="">
        <div class="form-group">
            <label for="email">Email :</label>
            <input type="email" name="email" id="email">
        </div>  
        <div class="form-group">
            <label for="password">Mot de passe :</label>
            <input type="password" name="password" id="password">
        </div>  
        <button type="submit" name="submit">Se connecter</button>
    </form>
</body>
</html>