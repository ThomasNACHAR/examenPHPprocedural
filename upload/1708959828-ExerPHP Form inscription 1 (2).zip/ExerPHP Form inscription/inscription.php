<?php
session_start();
require 'db.php';
//fonction générer la clé
function createCle()
{
   $caracteres = 'azertyuiopqsdfghjklmwxcvbn1234567890AZERTYUIOPQSDFGHJKLMWXCVBN';
   $cle = '';
   for($i=0;$i<25;$i++)
   {
       $cle.= $caracteres[rand(0,strlen($caracteres)-1)]; 
   }
   return $cle;
}
//prépare la requete SQL
if(isset($_POST['submit'])){
     if(!empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST['email']) && !empty($_POST!empty['date'])){
      $req=$dbh->prepare("INSERT INTO users (nom,prenom,email,password,date,cle) VALUES(:nom,:prenom, :email,:password, :date, :cle)");
      $cle=createCle();
      $req->bindParam(":nom",$_POST['nom']);
      $req->bindParam(":prenom",$_POST['prenom']);
      $req->bindParam(":email",$_POST['email']);
      $req->bindParam(":date",$_POST['date']);
      $req->bindParam(':password','');
      $req->bindParam(":cle",$cle);
      //exécute la requete
      if($req->execute()){
    // envoyer un mail
//Load Composer's autoloader
require 'vendor/autoload.php';

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'dwwm2324.fr';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'contact@dwwm2324.fr';                     //SMTP username
    $mail->Password   = 'm%]E5p2%o]yc';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('contact@dwwm2324.fr', 'Exercice');
    $mail->addAddress($_POST['email'], $_POST['nom']);     //Add a recipient
    

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Confirmer votre inscription';
    $fichier = file_get_contents('mail.html');
    $fichier = str_replace('[PRENOM]',$_POST['prenom'],$fichier);
    $fichier = str_replace('[NOM]',$_POST['nom'],$fichier);
    $fichier = str_replace('[CLE]',$cle,$fichier);
    $mail->Body = $fichier;
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
      }

}


    }


   
    
    ?>