<?php
require 'db.php';
if(!empty($_GET['cle'])){
    $verif=$dbh->query('SELECT * FROM users WHERE cle="'.$_GET['cle'].'"');
    if($verif->rowCount()>0){
    ?>
    <form name="confirmation" method="POST" action="mdp.php"> 
    <div class="form-group">
            <label for="password1">Mot de passe :</label>
            <input type="password" name="password">
            <label for="password">Confirmer password :</label>
            <input type="password" name="password2">
            <input type="hidden" name="cle" value="<?=$_GET['cle'];?>" >
            <button type="submit" name="submit">Envoyer</button>
        </div>
    </form>
    <?php    
    }
}

?>