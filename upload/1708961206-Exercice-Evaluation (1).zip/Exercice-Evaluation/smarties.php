<?php
require('libs/smarty/Smarty.class.php');

$smarty = new Smarty;

?>