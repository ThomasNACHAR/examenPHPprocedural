<?php

$dsn = 'mysql:dbname=smarties;host=localhost';
$user = 'root';
$password = 'root';

$dbh = new PDO($dsn,$user,$password);
?>