<?php
/* Smarty version 3.1.48, created on 2024-02-15 19:16:03
  from '/Applications/MAMP/htdocs/Exercice-Evaluation/templates/login.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_65ce62f32036b0_28792462',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1a0601af5a4dca9f5250c006d2bdf8b18c5d23a4' => 
    array (
      0 => '/Applications/MAMP/htdocs/Exercice-Evaluation/templates/login.tpl',
      1 => 1708024561,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65ce62f32036b0_28792462 (Smarty_Internal_Template $_smarty_tpl) {
?><html>
<style>
form{
    justify-content: center;
    text-align: center;
    margin: 20px;
}
input{
    padding: 10px;
    margin: 10px;
}
button{
    padding: 5px;
    width: 100px;
}
p{
    font-size: 20px;
    font-weight: bold;
    text-align: center;
    justify-content: center;
}
</style>
<title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
<body>

<?php echo $_smarty_tpl->tpl_vars['login']->value;?>

<br>
<div class="descri">
<p>Connectez-vous vite à votre compte pour profiter pleinement, au plus profond, de toutes les fonctionalités que l'on propose. </p>
<br>
<p>Merci pour votre confionce.</p>
</div>
<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>

</body>

</html><?php }
}
