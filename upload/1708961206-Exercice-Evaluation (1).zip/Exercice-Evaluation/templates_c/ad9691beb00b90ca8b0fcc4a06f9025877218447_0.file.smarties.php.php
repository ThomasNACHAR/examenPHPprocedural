<?php
/* Smarty version 3.1.48, created on 2024-02-15 15:22:16
  from '/Applications/MAMP/htdocs/Exercice-Evaluation/smarties.php' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_65ce2c2874beb2_97477768',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ad9691beb00b90ca8b0fcc4a06f9025877218447' => 
    array (
      0 => '/Applications/MAMP/htdocs/Exercice-Evaluation/smarties.php',
      1 => 1708000847,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65ce2c2874beb2_97477768 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?php
';?>
require('libs/smarty/Smarty.class.php');

$smarty = new Smarty;

<?php echo '?>';
}
}
