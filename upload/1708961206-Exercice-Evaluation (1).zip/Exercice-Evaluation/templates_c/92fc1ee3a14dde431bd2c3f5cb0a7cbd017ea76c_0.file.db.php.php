<?php
/* Smarty version 3.1.48, created on 2024-02-15 14:38:18
  from '/Applications/MAMP/htdocs/Exercice-Evaluation/db.php' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_65ce21da320165_34583172',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '92fc1ee3a14dde431bd2c3f5cb0a7cbd017ea76c' => 
    array (
      0 => '/Applications/MAMP/htdocs/Exercice-Evaluation/db.php',
      1 => 1708007855,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65ce21da320165_34583172 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?php

';?>
$dsn = 'mysql:dbname=smarties;host=localhost';
$user = 'root';
$password = 'root';

$dbh = new PDO($dsn,$user,$password);
<?php echo '?>';
}
}
