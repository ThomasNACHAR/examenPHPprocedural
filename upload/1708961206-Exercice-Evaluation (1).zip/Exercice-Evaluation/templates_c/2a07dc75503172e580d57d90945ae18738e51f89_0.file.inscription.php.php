<?php
/* Smarty version 3.1.48, created on 2024-02-15 14:35:52
  from '/Applications/MAMP/htdocs/Exercice-Evaluation/inscription.php' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_65ce2148943146_27454403',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2a07dc75503172e580d57d90945ae18738e51f89' => 
    array (
      0 => '/Applications/MAMP/htdocs/Exercice-Evaluation/inscription.php',
      1 => 1708007673,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65ce2148943146_27454403 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?php
';?>
require_once('db.php');
include 'smarties.php';

//Haut de tête template smarty
$smarty -> assign('title','Club des cônes');
$smarty -> assign('principal','Rejoignez le gang des chasseurs de cônes de circulation 🚧');
//Pour renommer les photos et être sur d'avoir des noms uniques + verif l'extension.
function renommePhoto(){
if(is_uploaded_file($_FILES['photo']['tmp_name']))
        {
            $extension = ['.JPG','.jpg','.PNG','.png','.GIF','.gif'];
            $scan = strrchr($_FILES['photo']['name'],'.');
            if(in_array($scan,$extension))
            {
                $newname = time().$_FILES['photo']['name'];
            }
        }
        return $newname;
}

if(isset($_POST['submit']))
{
    if(!empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST['email']) && !empty($_POST['password']) && !empty($_FILES['photo']))
    {
        
        
        $password = password_hash($_POST['password'],PASSWORD_DEFAULT);
        $newname = renommePhoto();

        $requete=$dbh->prepare("INSERT INTO utilisateurs (nom,prenom,email,password,photo) 
                                VALUES (:nom,:prenom,:email,:password,:photo");

        $requete ->bindParam(':nom',$_POST['nom']);
        $requete ->bindParam(':prenom',$_POST['prenom']);
        $requete ->bindParam(':email',$_POST['email']);
        $requete ->bindParam(':password',$password);
        $requete ->bindParam(':photo',$newname);

        if($requete->execute())
        {
            echo 'Inscription réussie. Merci pour tout.';
        }else
        {
            echo 'Echec lors de l\'inscription, veuillez recommencer';
        }

        
    }
}
//Smarty form
$smarty->assign('form','<form action="inscription.php" method="POST" name="inscription">

<div class="form-group">
    <label for= "nom">Nom :</label>
    <input type="text" name="nom" id="nom">
 </div>

 <div class="form-group">
    <label for="prenom">Prénom :</label>
    <input type="text" name="prenom" id="prenom">
    </div>

    <div class="form-group">
    <label for="email">Mail : </label>
    <input type="email" name="email" id="email">
    </div>
    
    <div class="form-group">
    <label for="password">Password :</label>
    <input type="password" name="password" id="password">
    </div>

    <div class="form-group">
    <label for="photo">Petite photo de vous : </label>
    <input type="file" name="photo" id="photo">
    </div>
<button type="submit" name="submit" id="submit">Validez votre inscription 😘</button>

</form>');
$smarty->display('inscription.tpl');
<?php echo '?>';
}
}
