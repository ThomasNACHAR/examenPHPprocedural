<?php
/* Smarty version 3.1.48, created on 2024-02-15 15:51:02
  from '/Applications/MAMP/htdocs/Exercice-Evaluation/templates/inscription.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.48',
  'unifunc' => 'content_65ce32e6deb6c8_35804037',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c65b7f178a7fe2af8ece4539214c821dfd0f98f9' => 
    array (
      0 => '/Applications/MAMP/htdocs/Exercice-Evaluation/templates/inscription.tpl',
      1 => 1708012244,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65ce32e6deb6c8_35804037 (Smarty_Internal_Template $_smarty_tpl) {
?><html>
<title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
<body>
<h1><?php echo $_smarty_tpl->tpl_vars['principal']->value;?>
</h1>

<?php echo $_smarty_tpl->tpl_vars['form']->value;?>

<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>

</body>
</html><?php }
}
