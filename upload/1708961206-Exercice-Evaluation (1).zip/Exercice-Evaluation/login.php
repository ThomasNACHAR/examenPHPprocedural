<?php
include 'smarties.php';
require_once('db.php');
session_start();

if(isset($_POST['submit']))
{
   if(!empty($_POST['email']) && !empty($_POST['password']))
   {
    $quete = $dbh->prepare('SELECT * FROM utilisateurs WHERE email = :email LIMIT 1');
    $quete->bindValue(':email',$_POST['email'],PDO::PARAM_STR);
    $quete->execute();

    if($quete->rowCount()==0)
    {
        echo 'On ne vous connait pas encore...';
        exit;
    }
    $result = $quete->fetch(PDO::FETCH_ASSOC);
    if(password_verify($_POST['password'],$result['password']))
    {
        setcookie('id',$result['id'],(time()+3600));
        setcookie('passwd',$result['password'],(time()+3600));
        $infos = array(
            'id' => $result['id'],
            'passwd' => $result['password']
        );
        setcookie('user',serialize($infos),(time()+3600));
        echo 'Bonjour '.$result['prenom'].' '.$result['nom'].'. 🚦 🚧 🚀 ';
    }
    else{
        echo 'Veuillez créer un compte pour nous rejoindre.';
    }
   }
}


$smarty->assign('login','<form action="login.php" method="POST" name="login">

<div class="form-group">
   <label for= "email">Mail :</label>
   <input type="email" name="email" id="email">
</div>

<div class="form-group">
   <label for= "password">Password :</label>
   <input type="password" name="password" id="password">
</div>
<button type="submit" name="submit">Je rentre !</button>
</form>');






//Display
$smarty->display('login.tpl')
?>