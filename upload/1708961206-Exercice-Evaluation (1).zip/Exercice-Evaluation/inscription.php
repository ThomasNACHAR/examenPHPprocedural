<?php
require_once('db.php');
include 'smarties.php';


//Pour renommer les photos et être sur d'avoir des noms uniques + verif l'extension.
function renommePhoto(){
if(is_uploaded_file($_FILES['photo']['tmp_name']))
        {
            $extension = ['.JPG','.jpg','.PNG','.png','.GIF','.gif'];
            $scan = strrchr($_FILES['photo']['name'],'.');
            if(in_array($scan,$extension))
            {
                $newname = time().$_FILES['photo']['name'];
            }
        }
        return $newname;
}

if(isset($_POST['submit']))
{
    if(!empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST['email']) && !empty($_POST['password']) 
    && is_uploaded_file($_FILES['photo']['tmp_name']))
    {
        
        
        $password = password_hash($_POST['password'],PASSWORD_DEFAULT);
        $newname = renommePhoto();

        $quete= $dbh->prepare("INSERT INTO utilisateurs (nom,prenom,email,password,photo) 
                                VALUES (:nom,:prenom,:email,:password,:photo)");

        $quete ->bindParam(':nom',$_POST['nom'],PDO::PARAM_STR);
        $quete ->bindParam(':prenom',$_POST['prenom'],PDO::PARAM_STR);
        $quete ->bindParam(':email',$_POST['email'],PDO::PARAM_STR);
        $quete ->bindParam(':password',$password,PDO::PARAM_STR);
        $quete ->bindParam(':photo',$newname,PDO::PARAM_STR);

        if($quete->execute())
        {
            echo 'Inscription réussie. Merci pour tout.';
        }else
        {
            echo 'Echec lors de l\'inscription, veuillez recommencer';
        }

        
    }else{
        echo 'Noooooon';
    }
    
}

//Smarty form
//Haut de tête template smarty
$smarty -> assign('title','Club des cônes');
$smarty -> assign('principal','Rejoignez le gang des chasseurs de cônes de circulation 🚧');
//Le form
$smarty->assign('form','<form action="" method="POST" name="inscription" enctype="multipart/form-data">

<div class="form-group">
    <label for= "nom">Nom :</label>
    <input type="text" name="nom" id="nom">
 </div>

 <div class="form-group">
    <label for="prenom">Prénom :</label>
    <input type="text" name="prenom" id="prenom">
    </div>

    <div class="form-group">
    <label for="email">Mail : </label>
    <input type="email" name="email" id="email">
    </div>
    
    <div class="form-group">
    <label for="password">Password :</label>
    <input type="password" name="password" id="password">
    </div>

    <div class="form-group">
    <label for="photo">Petite photo de vous : </label>
    <input type="file" name="photo" id="photo">
    </div>
<button type="submit" name="submit" id="submit">Validez votre inscription 😘</button>

</form>');
$smarty->assign('footer', '<footer>Ca devrait marcher, mais ça ne marche pas, et ça ne fonctionne encore moins</footer>');
$smarty->display('inscription.tpl');
?>